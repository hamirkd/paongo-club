<?php

/**
 * @SWG\Info(title="My First API", version="1.0")
 */

/**
 * @SWG\Get(
 *     path="/api/v1/example",
 *     @SWG\Response(response="200", description="An example resource")
 * )
 */
